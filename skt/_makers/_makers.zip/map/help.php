<?php
$_name = "Mapa - IBE ORM";
$_position = 7;
$_description = "cria mapas,  localizados em _maps, para o aplicativo";
$_params = array(
    "app"=>"nome da aplicacao",
    "host"=>"host do banco [default = localhost]",
    "user"=>"usuario do banco [default = root]",
    "pass"=>"senha do banco [default = ]",
    "schm"=>"esquema do banco [default = test]"
);
$_example = "map host:192.168.1.5 user:guest pass:guest shcm:public";
